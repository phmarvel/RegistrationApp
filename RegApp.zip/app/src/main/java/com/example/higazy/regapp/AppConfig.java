package com.example.higazy.regapp;

/**
 * Created by Higazy on 16/06/2016.
 */
public class AppConfig {
    // Server user login url
    public static String URL_LOGIN = "http://socyle.com/intership/index.php/login";

    // Server user register url
    public static String URL_REGISTER = "http://socyle.com/intership/index.php/register";

}
